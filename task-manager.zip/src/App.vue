<script setup lang="ts">
import TaskList from "./components/TaskList.vue";
</script>

<template>
  <div class="my-20">
    <TaskList />
  </div>
</template>
